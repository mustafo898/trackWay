package dark.composer.trackway.data.directionHelper;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}