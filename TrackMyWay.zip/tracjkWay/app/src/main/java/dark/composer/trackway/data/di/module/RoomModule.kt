package dark.composer.carpet.data.di.module

import dagger.Module

@Module
object RoomModule {

//    @Singleton
//    @Provides
//    fun provideRoom(application: Application): Retrofit {
//        return Room.databaseBuilder(
//            application.applicationContext,
//            AppDatabase::class.java, "carpet"
//        ).build()
//    }
}