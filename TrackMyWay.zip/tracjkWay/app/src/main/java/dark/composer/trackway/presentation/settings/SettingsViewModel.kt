package dark.composer.trackway.presentation.settings

import androidx.lifecycle.ViewModel

class SettingsViewModel:ViewModel() {


}