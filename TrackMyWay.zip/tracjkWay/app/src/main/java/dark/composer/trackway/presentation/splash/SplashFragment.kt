package dark.composer.trackway.presentation.splash

import dark.composer.trackway.databinding.FragmentSplashBinding
import dark.composer.trackway.presentation.BaseFragment

class SplashFragment : BaseFragment<FragmentSplashBinding>(FragmentSplashBinding::inflate) {
    override fun onViewCreate() {

    }
}