package dark.composer.trackway.data.local

 class UserData{
     var username: String = ""
     var password: String = ""

     constructor(username: String, userPassword: String) {
         this.username = username
         this.password = userPassword
     }

     constructor()

 }